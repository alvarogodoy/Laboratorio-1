package Laboratorio;

public class Cliente {
    String nombre;
    String apellido;
    int dni;
    double sueldo;
    int nroCliente;
}
